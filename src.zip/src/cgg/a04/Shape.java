package cgg.a04;

public interface Shape {
    public Hit intersect(Ray r);
}
