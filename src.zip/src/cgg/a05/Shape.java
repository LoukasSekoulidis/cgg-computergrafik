package cgg.a05;

public interface Shape {
    public Hit intersect(Ray r);
}
