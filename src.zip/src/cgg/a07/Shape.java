package cgg.a07;

public interface Shape {
    public Hit intersect(Ray r);
}
