package cgg.a12;

import cgtools.Matrix;

public interface Animatable {
    void setTransformation(Matrix m);
}
