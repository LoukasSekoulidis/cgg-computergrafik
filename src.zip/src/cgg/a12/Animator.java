package cgg.a12;

public interface Animator {
    void update(double time);
}
